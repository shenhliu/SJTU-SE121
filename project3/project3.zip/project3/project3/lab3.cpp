#include "common.h"

using namespace std;

//You should only code here.Don't edit any other files in this 
int func1(int amount, vector<int>& coins)
{	

	return -1;

}

int func2(int amount, vector< vector<int> >& conquer)
{
	
	return -1;
}


double func3(int n,int hp,vector<int>& damage,vector<int>& edges) {
    
    return -1;
}